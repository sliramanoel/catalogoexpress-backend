const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

// Configurações do servidor
const PORT = process.env.PORT || 4000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb+srv://silvaliramanoel086:7FOtJhJSCAbw09Pn@catalogoexpress.cp8lvzm.mongodb.net/?retryWrites=true&w=majority&appName=catalogoexpress';

// Conecta ao banco de dados
mongoose.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('MongoDB Conectado com sucesso!');
}).catch(err => {
  console.error('Erro ao conectar ao MongoDB:', err.message);
  process.exit(1);
});

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Rotas
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/products', require('./routes/productRoutes'));
app.use('/api/categories', require('./routes/categoryRoutes'));
app.use('/api/address', require('./routes/addressRoutes'));
app.use('/api/cart', require('./routes/cartRoutes'));
app.use('/api/orders', require('./routes/orderRoutes'));
app.use('/api/users', require('./routes/userRoutes'));
app.use('/api/ping', require('./routes/pingRoutes'));

// Adicionando tratamento de erros
app.use((err, req, res, next) => {
  console.error('Erro:', err);
  res.status(500).json({ error: 'Erro interno do servidor' });
});

// Exportando a função para o Netlify
exports.handler = async (event, context) => {
  return new Promise((resolve, reject) => {
    const listener = app.listen(PORT, () => {
      console.log(`Servidor rodando na porta ${PORT}`);
    });

    const request = event;
    const response = {};

    const server = http.createServer(app);
    server.on('request', (req, res) => {
      request.method = req.method;
      request.headers = req.headers;
      request.body = event.body;

      app(request, response, (err) => {
        if (err) {
          reject(err);
        } else {
          resolve({
            statusCode: response.statusCode || 200,
            headers: response.headers,
            body: response.body
          });
        }
        server.close();
      });
    });

    server.listen(PORT, () => {
      console.log(`Servidor rodando na porta ${PORT}`);
    });
  });
};
