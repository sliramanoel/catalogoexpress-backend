const credentials = {
    MONGO_URI: "mongodb+srv://catalogoexpress:catalogoexpress123@cluster0.mongodb.net/catalogoexpress?retryWrites=true&w=majority",
    JWT_SECRET: "catalogoexpress_jwt_secret_2025"
};

module.exports = credentials;
